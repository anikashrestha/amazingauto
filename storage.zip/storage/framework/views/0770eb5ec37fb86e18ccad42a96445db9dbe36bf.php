<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="content-wrapper">
    <div class="panel pandel-default">
        <div class="panel-heading">
       <h1 style="text-align:center">     
        View Gallery
       </h1>
            
        </div>
     
      
        <?php if(Auth::check()): ?>
        <?php if(Auth::user()->isAdmin()): ?>
        <div class = "pull-right">
                    <p>
                        <a href="/admin/gallery/create" class ="btn btn-primary btn-md"><span class = "glyphicon glyphicon-plus"> </span></a>
                    </p>
                    </div>
                    <br><br>
                 

<?php endif; ?>
<?php endif; ?>
        
        <div class="panel-body">
                <form action="<?php echo e(route('gallerysearch')); ?>" method="GET" style="margin-bottom:30px">
                                        
                        <div class="input-group">
                                        <input type="text" name="query" value="<?php echo e(request()->input('query')); ?>" class="form-control" placeholder="Search">
                                        <span class="input-group-btn">
                                <button type="submit" class="btn btn-default">
                                        <span class="fa fa-search"></span>
                                </button>
                                </span>
                        </div>
                        </form>
      
      <?php if(count($albums) > 0): ?>
      <?php
      $colcount = count($albums);
      $i = 1;
      
      ?>
      <div class ="albums">
      <div class ="row">
      <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($i == $colcount): ?>
      <div class ="col-md-4 col-lg-3" style="padding:12px;">
      <a href="/admin/gallery/<?php echo e($album->id); ?>">
      <img class ="thumnail" src="/storage/album_covers/<?php echo e($album->cover_image); ?>" alt="<?php echo e($album->name); ?>">
      </a>
      <h4 style="text-align: center;"><?php echo e($album->name); ?></h4>
      
      <?php if(Auth::check()): ?>
      <?php if(Auth::user()->isAdmin()): ?>
      <div style="text-align: center;margin-left:50px;">
      <a  href="/admin/gallery/edit/<?php echo e($album->id); ?>" class="btn btn-success btn-xs">Edit</a>
      <a  onclick="return confirm('are you sure you want to delele?')" href="/admin/gallery/delete/<?php echo e($album->id); ?>" class="btn btn-danger btn-xs">Delete</a>
      </div>  
      <?php endif; ?>
      <?php endif; ?>
    </div>
      
      <?php else: ?>
      <div class = "col-md-4 col-lg-3" style="padding:12px;">
      <a href= "/admin/gallery/<?php echo e($album->id); ?>">
      <img class="thumbnail" src="/storage/album_covers/<?php echo e($album->cover_image); ?>" alt="<?php echo e($album->name); ?>" />
      </a>
      
      <h4 style="text-align: center;" ><?php echo e($album->name); ?></h4>
      <div style="text-align:center;margin-left:50px;">
      <a href="/admin/gallery/edit/<?php echo e($album->id); ?>" class="btn btn-success btn-xs">Edit</a>
      <a  onclick="return confirm('are you sure you want to delele?')" href="/admin/gallery/delete/<?php echo e($album->id); ?>" class="btn btn-danger btn-xs">Delete</a>
      </div>
      
      
      <?php endif; ?>
      
      <?php if($i % 4 == 0): ?>
      </div>
      </div>
      
      <div class = "row" >
          <?php else: ?>
        
      </div>
      <?php endif; ?>
      <?php $i++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      </div>
      <?php else: ?>
      <p>No Albums To Display</p>
      <?php endif; ?>
    </div>
      </div>
    </div>
<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>