<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="content-wrapper">
        <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
              View About Us List
               </h1>
                    
                </div>

                <div class="container">
                        <main class="py-4">
                                <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </main>
                    </div>
                    
                    <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->isAdmin()): ?>
                    <div class = "pull-right">
                        <p>
                            <a href="/admin/about/create" class ="btn btn-primary btn-md"><span class = "glyphicon glyphicon-plus"> </span></a>
                        </p>
                        </div>
                        <br><br>
                        <?php endif; ?>
                        <?php endif; ?>

                    <div class="panel-body">
                   

    <?php if(count($abouts)>0): ?>
   

     <table class="table table-responsive table-bordered table-hover table-striped">
    <tr>
        <th>Id</th>
        <th>Title</th>
        <th>Text</th>
        <th>Show in Site</th> 
        <?php if(Auth::check()): ?>
        <?php if(Auth::user()->isAdmin()): ?>
        <th>Action</th>  
        <?php endif; ?>
        <?php endif; ?>
         
    </tr> 
    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($about->id); ?></td>
    <td><?php echo e($about->title); ?></td>
    <td style="width:40%;"><?php echo e($about->description); ?></td>
    <td><?php echo e(($about->status?'Show':'Dont Show')); ?></td>
    
    
    <?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
    <td >   
        <a  href="/admin/about/edit/<?php echo e($about->id); ?>" class="btn btn-info btn-xs">Edit</a>
    <a onclick="return confirm('are you sure you want to delele?')" href="/admin/about/<?php echo e($about->id); ?>" class="btn btn-danger btn-xs">Delete</a>
    
</td>
<?php endif; ?>
<?php endif; ?>

  
  
   
</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </table>
    <div class="mx-auto">
        <?php echo e($abouts->links()); ?>

</div>
 <?php else: ?>
 <p>No About Us Content Found</p>
 <?php endif; ?>
</div>
</div>
</div>
<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/about/index.blade.php ENDPATH**/ ?>