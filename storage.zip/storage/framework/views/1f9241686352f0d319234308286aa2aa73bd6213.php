<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
                <div class="panel pandel-default">
                                <div class="panel-heading">
                               <h1 style="text-align:center">     
                              Add Introduction
                               </h1>
                                    <br>
                                    <small style="text-align:center">All filed with <label class="required-field-class">*</label> are mandatory.</small>
                                </div>

      <div class="panel-body">
                <form action="<?php echo e(route('admin.introductions.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                     
                        <div class="form-group <?php echo e($errors->has('title')?'has-error':''); ?>">
                            <label for="name">Title</label>
                            <input type="text" class="form-control" name="title" id="title" placeholder="Title" value="<?php echo e(old('title')); ?>">
                            <?php if($errors->has('title')): ?>
                            <span class="help-block">
                                <?php echo e($errors->first('title')); ?>

                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('text')?'has-error':''); ?>">
                            <label for="text">Text<label class="required-field-class">*</label></label>
            
                            <textarea style="height: 200px;" name="text" id="body" cols="5" rows="10" class="form-control"><?php echo e(old('text')); ?></textarea>
                    <?php if($errors->has('text')): ?>
                    <span class="help-block">
                            <?php echo e($errors->first('text')); ?>

                    </span>
                    <?php endif; ?>
                    </div>
                       
                                <div class="form-group">
                               <label for="image">Image<label class="required-field-class">*</label></label>
                               <input type="file" class="form-control" name="image" id="image">
                               <small>Please Upload Image Size up to 2mb</small>
                               <?php if($errors->has('image')): ?>
                               <span class="help-block">
                                       <?php echo e($errors->first('image')); ?>

                               </span>
                               <?php endif; ?>       
                        </div>

                      
            
    
        
                        <div class="form-group">
                            <button class="btn btn-success">
                               Add  Introduction
                            </button>
                        </div>
        
                    </form>
                </div>
            

        </div>
</div>

        <?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/introductions/create.blade.php ENDPATH**/ ?>