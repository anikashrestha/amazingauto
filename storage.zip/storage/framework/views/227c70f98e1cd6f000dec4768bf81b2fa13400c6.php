<!-- new arrival section new start- -->
<div class="backgroundcolorcustomize" style="margin-top:-16px">

<div class="container" >
			<section class="ftco-section ftco-category ftco-no-pt ">
				<button class="buttonastext "  onclick="myFunction11()" >Body Type</button>
				<!-- <button class="buttonastext ml-3"  onclick="myFunction22()"  ><a href = "brand"> Brand</a></button> -->
				<button class="buttonastext ml-3 "  onclick="myFunction22()"  >Brand </button>
				 
				<p id="bodytypescript"  style="float:right;" > <a href = "body" style="text-decoration:none;">View All Body Type.. </a> </p>
				<p id="brandmorescript" style="float:right; display:none;"> <a href = "brand" style="text-decoration:none;">View All Brand.. </a> </p>
				 
				</section>
	    </div>
			
					<section class="ftco-section ftco-category ftco-no-pt "  >
			<div class="container newrrivalbrand" >
				
				<div id="myDIV11"> 
					<ul class="secondndpart">
							<li >
									<a  href="#" >
										<div class="bgimage-manufactor ftco-animate  suv"></div>
										<span class="spanarrival" >SUV</span>
									</a>
							</li>
							<li >
									<a  href="#" >
										<div class="bgimage-manufactor ftco-animate sedan"></div>
										<span class="spanarrival">SEDAN</span>
									</a>
							</li>		
							<li >
									<a  href="#" >
										<div class="bgimage-manufactor ftco-animate wagon"></div>
										<span class="spanarrival">WAGON</span>
									</a>
							</li>
							<li >
									<a  href="#" >
										<div class="bgimage-manufactor ftco-animate hatch"></div>
										<span class="spanarrival">HATCH</span>
									</a>
							</li>
							<li >
									<a  href="#" >
										<div class="bgimage-manufactor ftco-animate ute"></div>
										<span class="spanarrival">UTEs</span>
									</a>
							</li>
							<li >
									<a  href="#" >
										<div class="bgimage-manufactor ftco-animate convertible"></div>
										<span class="spanarrival">CONVERTIBLE</span>
									</a>
							</li>
					</ul>
				</div>


				<div id="myDIV22"> 

					<ul class="secondndpart">
	
								<li >
										<a  href="#" style="background-color:white">
											<i class="bgimage-manufactor ftco-animate ford"></i>
											<span class="spanarrival">FORD</span>
											
										</a>
								</li>
								<li >
										<a  href="#" >
											<div class="bgimage-manufactor ftco-animate toyota"></div>
											<span class="spanarrival">TOYOTA</span>
										</a>
								</li>		
								<li >
										<a  href="#" >
											<div class="bgimage-manufactor ftco-animate tata"></div>
											<span class="spanarrival">TATA</span>
										</a>
								</li>
								<li >
										<a  href="#" >
											<div class="bgimage-manufactor ftco-animate mahindra"></div>
											<span class="spanarrival">MAHINDRA</span>
										</a>
								</li>
								<li >
										<a  href="#" >
											<div class="bgimage-manufactor ftco-animate isuzu"></div>
											<span class="spanarrival">ISUZU</span>
										</a>
								</li>
								<li >
										<a  href="#" >
											<div class="bgimage-manufactor ftco-animate greatwall"></div>
											<span class="spanarrival">GREAT WALL</span>
										</a>
								</li>
					</ul>
				</div>
		</div>
	</section>




</div>

<script>
	// function myFunction1() {
	//   var x = document.getElementById("myDIV1");
	//   var y = document.getElementById("myDIV2");
	// 	x.style.display = "block";
	// 	 y.style.display = "none";
	// }
	// function myFunction2() {
	// 	var x = document.getElementById("myDIV1");
	// 	 var y = document.getElementById("myDIV2");
	  
	// 	y.style.display = "block";
	// 	 x.style.display = "none";
	// }



	// -------------------------
	// function myFunction11() {
	//   var a = document.getElementById("myDIV11");
	//   var b = document.getElementById("myDIV22");
	// 	a.style.display = "block";
	// 	 b.style.display = "none";
	// }
	// function myFunction22() {
	// 	var a = document.getElementById("myDIV11");
	// 	 var b = document.getElementById("myDIV22");
	  
	// 	b.style.display = "block";
	// 	 a.style.display = "none";
	// }
	// ---------------------



	 
	function myFunction11() {
	  var a = document.getElementById("myDIV11");
	  var b = document.getElementById("myDIV22");
	  var c = document.getElementById("bodytypescript");
	  var d = document.getElementById("brandmorescript");
		a.style.display = "block";
		c.style.display = "block";
		 b.style.display = "none";
		d.style.display = "none";
	}
	function myFunction22() {
		var a = document.getElementById("myDIV11");
	    var b = document.getElementById("myDIV22");
		var c = document.getElementById("bodytypescript");
	    var d = document.getElementById("brandmorescript");
	  
		b.style.display = "block";
		d.style.display = "block";
		 a.style.display = "none";
		 c.style.display = "none";
		 }
	</script>
<!-- new arrival end new---><?php /**PATH F:\laravel_Project\rental1\resources\views/inc/bodytype.blade.php ENDPATH**/ ?>