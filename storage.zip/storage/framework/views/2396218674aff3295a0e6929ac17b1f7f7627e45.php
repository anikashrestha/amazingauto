<body class="goto-here">
  <nav class="navbar navbar-expand-lg navbar-dark  bg-dark ftco-navbar-light bg-faded" >
		<div class="container">
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<a class="navbar-brand" href="#">
				<?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<img src="/storage/logos/<?php echo e($logo->logo); ?>" alt="<?php echo e($logo->title); ?>" width="70" height="50">					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	 
			</a>    
	      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	        <ul class="navbar-nav ml-auto">
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($item->children->count() > 0): ?>
	          		<li class="nav-item dropdown">
									<a class="nav-link dropdown-toggle" href="=<?php echo e($item->link); ?> " id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<?php echo e($item->title); ?>

									</a>								
									<div class="dropdown-menu" aria-labelledby="dropdown04">									
										<?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<a class="dropdown-item" href="=<?php echo e($submenu->link); ?>">
												<?php echo e($submenu->title); ?>

											</a>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</li>
							<?php else: ?>
								<li class="nav-item"><a href=<?php echo e($item->link); ?> class="nav-link"><?php echo e($item->title); ?></a></li>
							<?php endif; ?>	
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
	        </ul>
	      </div>
	    </div>
	  </nav>


	  
    <!-- END nav -->
    <?php /**PATH F:\laravel_Project\rental1\resources\views/inc/nav.blade.php ENDPATH**/ ?>