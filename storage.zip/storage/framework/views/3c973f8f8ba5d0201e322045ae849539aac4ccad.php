<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
        <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
             Create Menu
               </h1>
                    <br>
                    <small style="text-align:center">All filed with <label class="required-field-class">*</label> are mandatory.</small>
                </div>


        <div class="panel-body">
            <form  action="<?php echo e(route('admin.menus.store')); ?>" method="POST" >
                <?php echo e(csrf_field()); ?>

             
                <div class="form-group <?php echo e($errors->has('title')?'has-error':''); ?>">
                    <label for="name">Title<label class="required-field-class">*</label></label>
                    <input type="text" class="form-control" name="title" id="title" value="<?php echo e(old('title')); ?>">
                    <?php if($errors->has('title')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('title')); ?>

                    </span>
                    <?php endif; ?>
                </div>
                <div class = "form-group">
                <label><input type="checkbox" name="parent_id"  id="check" onchange="show(this.checked)"> Click it if it have parent</label>
                </div>
             
                <div id="hiddenField"  style="display:none;"  class="form-group <?php echo e($errors->has('parent_id')?'has-error':''); ?>">
                    <label for="parent_id">Parent Menu<label class="required-field-class">*</label></label>
                    <select name="parent_id" id="parent_id" name="hidden" class="form-control">
                            
                        <option hidden>0</option> 
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php if($errors->has('parent_id')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('parent_id')); ?>

                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php echo e($errors->has('display_order')?'has-error':''); ?>">
                    <label for="display_order">Display Order<label class="required-field-class">*</label></label>
                    <input type="number" class="form-control" name="display_order" id="display_order" value="<?php echo e(old('display_order')); ?>">
                    <?php if($errors->has('display_order')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('display_order')); ?>

                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php echo e($errors->has('link')?'has-error':''); ?>">
                    <label for="link">Link</label>
                    <input type="text" class="form-control" name="link" id="link" value="<?php echo e(old('link')); ?>">
                    <?php if($errors->has('link')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('link')); ?>

                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <button class="btn btn-success">
                        Add Menu
                    </button>
                </div>

            </form>
        </div>
    
    </div>
</div>
<script type="text/javascript">
 function show(checked){
     if(checked == true){
         $('#hiddenField').fadeIn();
     }else{
         $('#hiddenField').fadeOut();
     }
 }
    </script>
    <?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/menus/create.blade.php ENDPATH**/ ?>