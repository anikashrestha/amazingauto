<!-- review section start--->
<div class="backgroundcolorcustomize">

<div class="container">

	<section class="ftco-section ftco-category ftco-no-pt ">
		<p class="buttonastext">Review</p>
	</section>
</div>

<section class="ftco-section ftco-category ftco-no-pt ">
	<div class="container">
		<!-- pictur part -->
		<div class="row ">
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-6 order-md-last align-items-stretch d-flex">

						<div class="category-wrap ftco-animate img d-flex align-items-end"
							style="background-image: url(images/hummer.jpg); ">

							<div class="text px-3 py-1">
								<h2 class="mb-0"><a href="#">Hummer</a></h2>
							</div>



						</div>
						</br>
					</div>

					<div class="col-md-6">


						<div class="category-wrap ftco-animate img d-flex align-items-end"
							style="background-image: url(images/defender.jpg);">
							<div class="text px-3 py-1">
								<h2 class="mb-0"><a href="#">Land Rover Defender</a></h2>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-4">

				<div class="category-wrap ftco-animate img d-flex align-items-end"
					style="background-image: url(images/rangerover.jpg);">
					<div class="text px-3 py-1">
						<h2 class="mb-0"><a href="#">Range Rover</a></h2>
					</div>
				</div>
			</div>
		</div>



		<!-- review part -->



	</div>
</section>
</div>
<!-- review section end--->
<?php /**PATH F:\laravel_Project\rental1\resources\views/inc/review.blade.php ENDPATH**/ ?>