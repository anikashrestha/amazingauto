<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .hidden{

        display:none;
    }
</style>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
</style>
<div class="content-wrapper">
        <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
             Add About Us Content
               </h1>
                    <br>
                    <small style="text-align:center">All filed with <label class="required-field-class">*</label> are mandatory.</small>
            </div>


        <div class="panel-body">
            <form  action="<?php echo e(route('admin.about.store')); ?>" method="POST" >
                <?php echo e(csrf_field()); ?>


                <div class="form-group <?php echo e($errors->has('heading')?'has-error':''); ?>">
                    <label for="heading">Heading<label class="required-field-class">*</label></label>
                    <input type="text" class="form-control" name="heading" id="heading" value="<?php echo e(old('heading')); ?>">
                    <?php if($errors->has('heading')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('heading')); ?>

                    </span>
                    <?php endif; ?>
                </div>

            
                        <div class="form-group <?php echo e($errors->has('title')?'has-error':''); ?>">
                                <label for="title">Title<label class="required-field-class">*</label></label>
                                <input type="text" class="form-control" name="title" id="title" value="<?php echo e(old('title')); ?>">
                                <?php if($errors->has('title')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('title')); ?>

                                </span>
                                <?php endif; ?>
                            </div>

                        
              
               
                <div class="form-group <?php echo e($errors->has('description')?'has-error':''); ?>">
                        <label for="content">Description<label class="required-field-class">*</label></label>
        
                        <textarea style="height: 200px;" name="description" id="description" cols="5" rows="10" class="form-control"><?php echo e(old('description')); ?></textarea>
                <?php if($errors->has('description')): ?>
                <span class="help-block">
                        <?php echo e($errors->first('description')); ?>

                </span>
                <?php endif; ?>
                </div>


                <div class="form-group <?php echo e($errors->has('status')?'has-error':''); ?>">
                        <input type="checkbox" value="<?php echo e(old('status')); ?>"  id="status" name="status">
                                <label for="status">Show</label>
            </div>
               
          
        <div class="form-group">
                    <button class="btn btn-success">
                        Add
                    </button>
                </div>

            </form>
        </div>
    
    </div>
</div>
<script src="https://cloud.tinymce.com/5/tinymce.min.js"></script>
<script type="text/javascript">
tinymce.init({
    selector: 'textarea',
    plugins: "textcolor",
    height : "480"
    
  });
  </script>

    <?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/about/create.blade.php ENDPATH**/ ?>