
  </div>
  <footer class="main-footer">
    <strong>Copyright &copy; <a href="">ESC Pvt Ltd</a>.</strong> All rights
    reserved.
  </footer>



 

<!-- ./wrapper -->


<!-- jQuery 3 -->
<script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

<!-- AdminLTE App -->
<script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/partnerproduct.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/partnerservice.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>	
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.6/jquery.fancybox.js"></script>

<?php echo $__env->yieldContent('script-import-section'); ?>

<script>
   
        <?php if(Session::has('success')): ?>
            toastr.success("<?php echo e(Session::get('success')); ?>");
        <?php endif; ?>;
        <?php if(Session::has('info')): ?>
            toastr.info("<?php echo e(Session::get('info')); ?>");
        <?php endif; ?>;
        <?php echo $__env->yieldContent('script-section'); ?>;


  $('form').on('focus', 'input[type=number]', function (e) {
  $(this).on('mousewheel.disableScroll', function (e) {
    e.preventDefault()
  })
  })
  $('form').on('blur', 'input[type=number]', function (e) {
  $(this).off('mousewheel.disableScroll')
  })
  
     $('#imageButton').click(function(){
        $('#imageModal').modal('show');
    });
   
    

</script>


<?php echo $__env->yieldContent('script'); ?>
	

</body>
</html>
<?php /**PATH F:\laravel_Project\rental1\resources\views/admin/adminfooter.blade.php ENDPATH**/ ?>