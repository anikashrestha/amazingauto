<?php echo $__env->make('layouts.metaheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <section class="ftco-section ftco-no-pb ftco-no-pt bg-light">
		<div class="container">
			<div class="row">				
				<div class="col-md-7 py-5 wrap-about pb-md-5 ftco-animate">
	                <div class="heading-section-bold mb-4 mt-md-5">
                        <div class="ml-md-0">
                            <h2 class="mb-4">Welcome to car buy &amp; sell website</h2>
                        </div>
	                </div>
	                <div class="pb-md-5">
                        <?php $__currentLoopData = $abouts ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <h4 style="color:#07858d;"><?php echo e($about->title); ?></h4>
                                <p><?php echo $about->description; ?></p>
                            </div>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
    </section>
 <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
 <?php echo $__env->make('layouts.metafooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
 
 <style type="text/css">
 
 </style>
 <?php /**PATH F:\laravel_Project\rental1\resources\views/about.blade.php ENDPATH**/ ?>