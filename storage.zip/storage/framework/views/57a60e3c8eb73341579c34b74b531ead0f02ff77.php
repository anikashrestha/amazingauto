<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
                <div class="panel pandel-default">
                                <div class="panel-heading">
                               <h1 style="text-align:center">     
                              Create Gallery
                               </h1>
                                    <br>
                                    <small style="text-align:center">All filed with <label class="required-field-class">*</label> are mandatory.</small>
                                </div>

      <div class="panel-body">
                <form action="<?php echo e(route('admin.gallery.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                     
                        <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
                            <label for="name">Name<label class="required-field-class">*</label></label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Gallery Name" value="<?php echo e(old('name')); ?>">
                            <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <?php echo e($errors->first('name')); ?>

                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('description')?'has-error':''); ?>">
                                        <label for="description">Description<label class="required-field-class">*</label></label>
                        
                                        <textarea name="description" id="experience_required" placeholder="Description" cols="5" rows="5" class="form-control"><?php echo e(old('description')); ?></textarea>
                                <?php if($errors->has('description')): ?>
                                <span class="help-block">
                                        <?php echo e($errors->first('description')); ?>

                                </span>
                                <?php endif; ?>
                                </div>

                                <div class="form-group">
                               <label for="cover_image">Cover Image<label class="required-field-class">*</label></label>
                               <input type="file" class="form-control" name="cover_image" id="cover_image">
                               <small>Please Upload Image Size up to 2mb</small>
                               <?php if($errors->has('cover_image')): ?>
                               <span class="help-block">
                                       <?php echo e($errors->first('cover_image')); ?>

                               </span>
                               <?php endif; ?>       
                        </div>
        
                        <div class="form-group">
                            <button class="btn btn-success">
                                Create Gallery
                            </button>
                        </div>
        
                    </form>
                </div>
            

        </div>
</div>

        <?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/gallery/create.blade.php ENDPATH**/ ?>