<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
    <div class="panel pandel-default">
        <div class="panel-heading">
            <h1 style="text-align:center">
                Add Map Co-ordinates
            </h1>
            <br>
            <small style="text-align:center">All filed with <label class="required-field-class">*</label> are
                mandatory.</small>
        </div>

        <div class="panel-body">
            <form action="<?php echo e(route('admin.map.store')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>


                <div class="form-group <?php echo e($errors->has('lat')?'has-error':''); ?>">
                    <label for="lat">Lattitude<label class="required-field-class">*</label></label>
                    <input type="text" class="form-control" name="lat" id="lat" placeholder="Lattitude"
                        value="<?php echo e(old('lat')); ?>">
                    <?php if($errors->has('lat')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('lat')); ?>

                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php echo e($errors->has('lon')?'has-error':''); ?>">
                    <label for="lon">Longitude<label class="required-field-class">*</label></label>
                    <input type="text" class="form-control" name="lon" id="lat" placeholder="Longitude"
                        value="<?php echo e(old('lon')); ?>">
                    <?php if($errors->has('lon')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('lon')); ?>

                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('lon')?'has-error':''); ?>">
                    <label for="address">Location<label class="required-field-class">*</label></label>
                    <input type="text" class="form-control" name="address" id="address" placeholder="Address"
                        value="<?php echo e(old('address')); ?>">
                    <?php if($errors->has('address')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('address')); ?>

                    </span>
                    <?php endif; ?>
                </div>


                <div class="form-group">
                    <button class="btn btn-success">
                        Save
                    </button>
                </div>

            </form>
        </div>


    </div>
</div>

<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/map/create.blade.php ENDPATH**/ ?>