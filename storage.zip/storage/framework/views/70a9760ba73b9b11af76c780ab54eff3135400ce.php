<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="content-wrapper">
        <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
              View Introduction
               </h1>
                    
                </div>

                <div class="container">
                        <main class="py-4">
                                <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </main>
                    </div>

                    <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->isAdmin()): ?>
                    <div class = "pull-right">
                                <p>
                                    <a href="/admin/introductions/create" class ="btn btn-primary btn-md"><span class = "glyphicon glyphicon-plus"> </span></a>
                                </p>
                                </div>
                                <br><br>
                             
     
        <?php endif; ?>
        <?php endif; ?>

                    <div class="panel-body">
                  

    <?php if(count($introductions)>0): ?>
   <table class = "table table-bordered table-striped">
<tr>
    <th>Id</th>
    <th>Title</th>
    <th>Text</th>
    <th style="wdith:20px;">Image</th>
    <?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
    <th>Action</th>
     <?php endif; ?>
     <?php endif; ?>
</tr>
<?php $__currentLoopData = $introductions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($intro->id); ?></td>
<td><?php echo e($intro->title); ?></td>
<td><?php echo e($intro->text); ?></td>
<td>
<img class="img-responsive" style="height:50px;" src="/storage/introductions/<?php echo e($intro->image); ?>" >
</td>
<?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
<td>
        <a  href="/admin/introductions/edit/<?php echo e($intro->id); ?>" class="btn btn-info btn-xs">Edit</a>
    <a onclick="return confirm('are you sure you want to delele?')" href="/admin/introductions/<?php echo e($intro->id); ?>" class="btn btn-danger btn-xs">Delete</a>
  
    </td>
    <?php endif; ?>
    <?php endif; ?>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>

 <?php else: ?>
 <p>No Introduction Found</p>
 <?php endif; ?>
</div>
</div>
</div>
<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/introductions/index.blade.php ENDPATH**/ ?>