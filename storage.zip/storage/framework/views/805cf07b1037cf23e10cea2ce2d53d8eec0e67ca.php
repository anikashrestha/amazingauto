<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="content-wrapper">

        <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
               <?php echo e($album->name); ?>

               </h1>
                    
                </div>
<div>
<a class="btn btn-danger btn-sm" href="/admin/gallery">Go Back</a>
<?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
<a class="btn btn-primary btn-sm" href="/admin/photos/create/<?php echo e($album->id); ?>">Upload Photo to ALbum</a>
<?php endif; ?>
<?php endif; ?>
</div>

<div class="container">
        <main class="py-4" style="margin-left:-35px;padding:21px;">
                <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </main>
    </div>



<?php if(count($album->photos) > 0): ?>
<?php
$colcount = count($album->photos);
$i = 1;

?>
<div class ="photos">
<div class ="row">
<?php $__currentLoopData = $album->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($i == $colcount): ?>
<div class ="col-md-4 col-lg-3" style="padding:12px;">
                <a data-fancybox="gallery" data-caption="<?php echo e($photo->description); ?>" href="/storage/photos/<?php echo e($photo->album_id); ?>/<?php echo e($photo->photo); ?>">
<img class ="thumnail" src="/storage/photos/<?php echo e($photo->album_id); ?>/<?php echo e($photo->photo); ?>" alt="<?php echo e($photo->title); ?>" >
</a>
<?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
<div style="text-align: center;margin-top:20px;">
                <a  onclick="return confirm('are you sure you want to delele?')" href="/admin/photos/delete/<?php echo e($photo->id); ?>" class="btn btn-danger btn-xs">Delete</a>
                </div>
                <?php endif; ?>
                <?php endif; ?>
</div>

<?php else: ?>
<div class = "col-md-4 col-lg-3" style="padding:12px;">
        <a data-fancybox="gallery" data-caption="<?php echo e($photo->description); ?>" href="/storage/photos/<?php echo e($photo->album_id); ?>/<?php echo e($photo->photo); ?>">
            <img class ="thumnail" src="/storage/photos/<?php echo e($photo->album_id); ?>/<?php echo e($photo->photo); ?>" alt="<?php echo e($photo->title); ?>" >
            </a>
            <div style="text-align:center;margin-top:20px;">
                       
                        <a  onclick="return confirm('are you sure you want to delele?')" href="/admin/photos/delete/<?php echo e($photo->id); ?>" class="btn btn-danger btn-xs">Delete</a>
                        </div>


<?php endif; ?>

<?php if($i % 4 == 0): ?>
</div>
</div>

<div class = "row" >
    <?php else: ?>
  
</div>
<?php endif; ?>
<?php $i++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
<?php else: ?>
<p>No Photo To Display</p>
<?php endif; ?>

      
        </div>
        </div>
    </div>
    <script>
                $("[data-fancybox]").fancybox();
                </script>
    <?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/gallery/show.blade.php ENDPATH**/ ?>