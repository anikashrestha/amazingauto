<section class="ftco-section ftco-degree-bg"> -->
    <div class="container">
        <div class="row">
            <div class="col-lg-8 ftco-animate">
			    <div class="row">
					<div class="col-md-12 d-flex ftco-animate">
		                <div class="blog-entry align-self-stretch d-md-flex">
		                    <div class="text d-block pl-md-4">
		                        <h3 class="heading"><a href="#">This page is under construction</a></h3>
		                        
		                    </div>
		                </div>
		            </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH F:\laravel_Project\rental1\resources\views/pages/send.blade.php ENDPATH**/ ?>