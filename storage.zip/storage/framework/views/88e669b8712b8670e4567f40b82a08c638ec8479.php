<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div class = "404" style="margin-left: 458px;margin-top: 161px;">
    <h1>Page Not Found</h1>
    <a href="/" >Go Back to Home</a>
    </div>
</body>
</html><?php /**PATH F:\laravel_Project\rental1\resources\views/errors/404.blade.php ENDPATH**/ ?>