<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
        <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
             Create User
               </h1>
                    <br>
                    <small style="text-align:center">All filed with <label class="required-field-class">*</label> are mandatory.</small>
                </div>


        <div class="panel-body">
        <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

             
                <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
                    <label for="name">Name<label class="required-field-class">*</label></label>
                    <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>">
                    <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('name')); ?>

                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('email')?'has-error':''); ?>">
                    <label for="name">Email<label class="required-field-class">*</label></label>
                    <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <?php echo e($errors->first('email')); ?>

                    </span>
                    <?php endif; ?>
                </div>

                  <div class="form-group <?php echo e($errors->has('role_id')?'has-error':''); ?>">
                        <label for="role_id">Role<label class="required-field-class">*</label></label>
                        <select name="role_id" id="role_id"  class="form-control">
                                
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php if($errors->has('role_id')): ?>
                        <span class="help-block">
                            <?php echo e($errors->first('role_id')); ?>

                        </span>
                        <?php endif; ?>
                    </div>

                <div class="form-group">
                    <button class="btn btn-success">
                        Create User
                    </button>
                </div>

            </form>
        </div>
    
    </div>
</div>

    <?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views//admin/users/create.blade.php ENDPATH**/ ?>