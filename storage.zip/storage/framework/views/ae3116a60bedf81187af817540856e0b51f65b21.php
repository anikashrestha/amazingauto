<footer class="ftco-footer ftco-section">
      <div class="container">
      <?php $__currentLoopData = $footers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="row ">
						<div class="col-md-4 col-lg-4">
								<h5 style="color:orange;">Quick links</h5>
								<ul style="list-style: none;">
												<?php $__currentLoopData = $quickLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quicklink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($quicklink->footer_id == $footer->id): ?>
										
												<li><a href="<?php echo e($quicklink->quick_links); ?>"><i class="fa fa-angle-double-right"></i> <?php echo e($quicklink->quick_links_name); ?></a></li>
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
						
														</ul>
						</div>
						<div class="col-md-4 col-lg-4">
								<h5 style="color:orange;">Useful links</h5>
								<ul style="list-style: none;">
								<?php $__currentLoopData = $usefulLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usefullink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($usefullink->footer_id == $footer->id): ?>
						
								<li><a href="<?php echo e($usefullink->useful_links); ?>"><i class="fa fa-angle-double-right"></i> <?php echo e($usefullink->useful_links_name); ?></a></li>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
						</div>
						<div class="col-md-4 col-lg-4">
								<h5 style="color:orange;">Contact Detail</h5>
								<ul style="list-style: none;">
												<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($contact->footer_id == $footer->id): ?>
										
												<li><?php echo e($contact->contact_info); ?></li>
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
						</div>


				</div>
				<div class="row">
						<div class="col-md-4 col-lg-12">
										<ul style="list-style: none;" class="list-unstyled list-inline social text-center">
										<?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sociallink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($sociallink->footer_id == $footer->id): ?>
						<li class="list-inline-item"><a href="<?php echo e($sociallink->social_links); ?>"><i class="<?php echo e($sociallink->social_icon); ?>"></i></a></li>
									 
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							 
									
								</ul>
						</div>
				
				</div>	
				<div class="row ">
								<div class="col-md-4 col-lg-12 ">
												
								<p style="text-align:center;"class ="h6"><?php echo e($footer->copyright); ?></p>
												
								</div>
						
						</div>	
				
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
    </footer>
    
  

  <!-- loader -->
  <!-- <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div> -->


<?php /**PATH F:\laravel_Project\rental1\resources\views/inc/footer.blade.php ENDPATH**/ ?>