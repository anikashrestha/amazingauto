<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="content-wrapper">
                <div class="panel pandel-default">
                                <div class="panel-heading">
                               <h1 style="text-align:center">     
                              Edit Banner
                               </h1>
                                    <br>
                                    <small style="text-align:center">All filed with <label class="required-field-class">*</label> are mandatory.</small>
                                </div>

      <div class="panel-body">
            <form action="<?php echo e(route('admin.banners.update',['id'=>$banner->id])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e($banner->id); ?>"/>
                        <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
                            <label for="name">Title<label class="required-field-class">*</label></label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Banner Name" value="<?php echo e($banner->name); ?>">
                            <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <?php echo e($errors->first('name')); ?>

                            </span>
                            <?php endif; ?>
                        </div>
                       <div>
                        <div class="form-group">
                                        
                                <img src="/storage/banners/<?php echo e($banner->banner); ?>" height="100px" width="200px" alt="<?php echo e($banner->name); ?>">
                                <br>
                                <small><a href="#" id="imageButton">View Image</a></small>
                            </div>
                          
                                <div class="form-group">
                                    <label for="banner">Change Banner</label>
                                <input type="file" class="form-control" name="banner" id="banner" value="/storage/banners/<?php echo e($banner->banner); ?>">
                                <small>Please Upload Image Size up to 2mb</small>
                            </div>
                            </div>

                            <div class="form-group">
                                    <input type="checkbox" value="<?php echo e($banner->status); ?>"  id="status" name="status" <?php echo ($banner->status==1 ? 'checked' : '')?>>
                                            <label for="status">Show in Home</label>
                                            </div>
                                        
            
                        <div class="form-group">
                            <button class="btn btn-success">
                                Edit Banner
                            </button>
                        </div>
        
                    </form>
                </div>

                                
        <div id="imageModal" class="modal fade" role="dialog">
                <div class="modal-dialog">
              
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title">Banner</h4>
                    </div>
                    <div class="modal-body">
                      <img src="/storage/banners/<?php echo e($banner->banner); ?>"  alt="" class="img-responsive">
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
              
                </div>
              </div>

            

        </div>
</div>
<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/banners/edit.blade.php ENDPATH**/ ?>