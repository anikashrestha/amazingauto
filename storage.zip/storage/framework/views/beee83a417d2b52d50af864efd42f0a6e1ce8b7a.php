
 <!-- ----to display  cars according to body type or brand------ -->



 <!-- ----to display brand type of body type on click of view all brand or view all bodytype------ -->

 <div class="backgroundcolorcustomize">
			<div class="container">
				<section class="ftco-section ftco-category ftco-no-pt ">
					<p class="buttonastext">Brand</p>
				</section>
			</div>
			<section class="ftco-section ftco-category ftco-no-pt backgroundcolorcustomize">

				<p style="visibility: hidden;">Gallery</p>
				<div class="container">
					<div class="row" style="margin-top: -120px;">
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
							<a href="#" class="img-prod"><img class="img-fluid brandbodyimage" src="images/brand/chevrolet.png"
										alt="Colorlib Template">
									<div class="overlay"></div>
								
								<div class="  textbrandbody py-3 pb-4 px-3 text-center">
									<h3> Chevrolet </h3>
									<div class="d-flex">
										
									</div>
                                </div>
                            </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid brandbodyimage" src="images/brand/fiat.png"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class="  textbrandbody py-3 pb-4 px-3 text-center">
									<h3>fiat</h3>
									<div class="d-flex">
										
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid brandbodyimage" src="images/brand/greatwall.png"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class="  textbrandbody py-3 pb-4 px-3 text-center">
									<h3>greatwall</h3>
									<div class="d-flex">
										
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid brandbodyimage" src="images/brand/honda.png"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class="  textbrandbody py-3 pb-4 px-3 text-center">
									<h3>honda</h3>
									<div class="d-flex">
										
									</div>
                                </div>
                                </a>
							</div>
						</div>


						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid brandbodyimage" src="images/brand/jeep.png"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class="  textbrandbody py-3 pb-4 px-3 text-center">
									<h3>jeep</h3>
									<div class="d-flex">
										
									</div>
                                    </a>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid brandbodyimage" src="images/brand/mg.png"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class="  textbrandbody py-3 pb-4 px-3 text-center">
									<h3>mg</h3>
									<div class="d-flex">
										
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid brandbodyimage" src="images/brand/nissan.png"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class="  textbrandbody py-3 pb-4 px-3 text-center">
									<h3>nissan</h3>
									<div class="d-flex">
										
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid brandbodyimage" src="images/brand/subaru.png"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class="  textbrandbody py-3 pb-4 px-3 text-center">
									<h3>subaru</h3>
									<div class="d-flex">
										
									</div>
                                </div>
                                </a>
							</div>
                        </div>
                        
                        
					</div>
				</div>
			</section>
		</div>




<!-- -------------to display each car------------------------------------------------------------------------------------------ -->
<div class="backgroundcolorcustomize">
			<div class="container">
				<section class="ftco-section ftco-category ftco-no-pt ">
					<p class="buttonastext">Land Rover</p>
				</section>
			</div>

				<!-- <p style="visibility: hidden;">Gallery</p> -->
				<div class="container"  >
					<div class="row" >

							<div style="float:left; width:35%;">
							
							<img style="float: left; margin: 0px 15px 15px 0px;" src="images/fordranger.jpg"/>
							</div>

							<div class="keyfeatures"style="float:right; width:60%; margin-left:5%"> 
							<h2>Features</h2>
							<p class="subtitile">Ford Ranger XL Hi-Ride</p>
							<ul>
								<li>4 cylinder Diesel Turbo Intercooled</li>
								<li>6 speed Automatic</li>
								<li>Rear Wheel Drive</li>
								<li>5 Star ANCAP Rating</li>
								<li>Diesel 7.8 L/100km</li>
							</ul>


							<p class="subtitile">Price: Rs. 6500000</p>
                            <a href = "contact" style="text-decoration:none;">
						<button class="enquirybutton" style="border-radius: 8px;  "> Enquiry Now</button></a>
						
					
						</div>
					</div>
				</div>
	</div>
<!-- -------------------------------------------------------------------------------------------- -->
	

  <div class="backgroundcolorcustomize">
			<div class="container">
				<section class="ftco-section ftco-category ftco-no-pt ">
					<p class="buttonastext">Sedan</p>
				</section>
			</div>
			<section class="ftco-section ftco-category ftco-no-pt backgroundcolorcustomize">

				<p style="visibility: hidden;">Gallery</p>
				<div class="container">
					<div class="row" style="margin-top: -120px;">
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-1.jpg"
										alt="Colorlib Template">
									<!-- <span class="status">30%</span> -->
									<div class="overlay"></div>
								
								<div class=" description text py-3 pb-4 px-3 text-center">
									<h3> Car name </h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span class="mr-2 price-dc">Rs 120000</span><span
													class="price-sale">Rs 80000</span></p>
										</div>
									</div>
                                </div>
                            </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-2.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class=" description text py-3 pb-4 px-3 text-center">
									<h3>Car name</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-3.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class=" description text py-3 pb-4 px-3 text-center">
									<h3>Car name</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-4.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class=" description text py-3 pb-4 px-3 text-center">
									<h3>Car name</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>


						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-5.jpg"
										alt="Colorlib Template">
									<span class="status">30%</span>
									<div class="overlay"></div>
								<div class=" description text py-3 pb-4 px-3 text-center">
									<h3>Car name</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span class="mr-2 price-dc">Rs 1200000</span><span
													class="price-sale">Rs 800000</span></p>
										</div>
									</div>
                                    </a>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-6.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class=" description text py-3 pb-4 px-3 text-center">
									<h3>Car name</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-7.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class=" description text py-3 pb-4 px-3 text-center">
									<h3>Car name</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-7.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class=" description text py-3 pb-4 px-3 text-center">
									<h3>Car name</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
                        </div>
                        
                        
					</div>
				</div>
			</section>
		</div>

	</div>  
 <!-------------------------------------------------------------------------------------------------->





 
	</div>
<!-------------------------------------------------------------------------------------------------->


<?php /**PATH F:\laravel_Project\rental1\resources\views/pages/brand.blade.php ENDPATH**/ ?>