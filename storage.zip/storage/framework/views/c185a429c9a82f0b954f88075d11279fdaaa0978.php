<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
        <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
              View Pages
               </h1>
                    
                </div>

                <div class="container">
                        <main class="py-4">
                                <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </main>
                    </div>

                    <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->isAdmin()): ?>
                    <div class = "pull-right">
                                <p>
                                    <a href="/admin/pages/create" class ="btn btn-primary btn-md"><span class = "glyphicon glyphicon-plus"> </span></a>
                                </p>
                                </div>
                                <br><br>
                             
     
        <?php endif; ?>
        <?php endif; ?>

                    <div class="panel-body">
                    <form action="<?php echo e(route('pagesearch')); ?>" method="GET" style="margin-bottom:30px">
                                        
                            <div class="input-group">
                                            <input type="text" name="query" value="<?php echo e(request()->input('query')); ?>" class="form-control" placeholder="Search">
                                            <span class="input-group-btn">
                                    <button type="submit" class="btn btn-default">
                                            <span class="fa fa-search"></span>
                                    </button>
                                    </span>
                            </div>
                            </form>

    <?php if(count($pages)>0): ?>
   

     <table class="table table-responsive table-bordered table-hover table-striped">
    <tr>
        <th>Id</th>
        <th>Title</th>
        <th>Slug</th>
        <th>Content</th>
        <th>Show in Site</th>   
        <?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
    <th>Action</th>
    <?php endif; ?>
    <?php endif; ?>  
         
    </tr> 
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($page->id); ?></td>
    <td><?php echo e($page->title); ?></td>
    <td><?php echo e($page->slug); ?></td>
    <td style="width:40%;"><?php echo $page->body; ?></td>
    <td><?php echo e(($page->status?'Show':'Dont Show')); ?></td>
    <?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
    <td>
        <a  href="/admin/pages/edit/<?php echo e($page->id); ?>" class="btn btn-info btn-xs">Edit</a>
    <a onclick="return confirm('are you sure you want to delele?')" href="/admin/pages/<?php echo e($page->id); ?>" class="btn btn-danger btn-xs">Delete</a>
    </td>
    <?php endif; ?>
    <?php endif; ?>
   
</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </table>
    <div class="mx-auto">
        <?php echo e($pages->links()); ?>

</div>
 <?php else: ?>
 <p>No Pages Found</p>
 <?php endif; ?>
</div>
</div>
</div>
<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>