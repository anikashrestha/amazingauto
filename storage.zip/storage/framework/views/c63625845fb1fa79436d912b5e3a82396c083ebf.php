<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">

      <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
              Add Photos to Gallery
               </h1>
                    <br>
                    <small style="text-align:center">All filed with <label class="required-field-class">*</label> are mandatory.</small>
                </div>
        

    <div class="panel-body">
                <form action="<?php echo e(route('admin.photos.store',['id'=>$album->id])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                <input type="hidden" name="album_id" value="<?php echo e($album->id); ?>" id="album_id"/>
                        
                        

                         

                                <div class="form-group">
                               <label for="photo">Photos<label class="required-field-class">*</label></label>
                               <input type="file" class="form-control" name="photo[]" multiple id="photo">
                               <?php if($errors->has('photo')): ?>
                               <span class="help-block">
                                       <?php echo e($errors->first('photo')); ?>

                               </span>
                               <?php endif; ?>       
                        </div>
        
                        <div class="form-group">
                            <button class="btn btn-success">
                                Add Photos
                            </button>
                        </div>
        
                    </form>
                </div>
      </div>
            

  
        </div>
        <?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\laravel_Project\rental1\resources\views/admin/photos/create.blade.php ENDPATH**/ ?>