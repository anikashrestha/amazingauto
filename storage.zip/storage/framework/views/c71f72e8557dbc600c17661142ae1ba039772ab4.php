<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
        <div class="panel pandel-default">
                <div class="panel-heading">
               <h1 style="text-align:center">     
              View Footer
               </h1>
                    
                </div>

                <div class="container">
                        <main class="py-4">
                                <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </main>
                    </div>

                    <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->isAdmin()): ?>
                    <div class = "pull-right">
                                <p>
                                    <a href="/admin/footers/create" class ="btn btn-primary btn-md"><span class = "glyphicon glyphicon-plus"> </span></a>
                                </p>
                                </div>
                                <br><br>
                             
     
        <?php endif; ?>
        <?php endif; ?>

                    <div class="panel-body">
                   

    <?php if(count($footers)>0): ?>
   

     <table class="table table-responsive table-bordered table-hover table-striped">
    <tr>
        <th>Id</th>
        <th>Copyright</th>
        <th>Office Detail</th>
        <th>Quick Links</th>
        <th>Useful Links</th>
        <th>Social Links</th>    
        <?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
    <th>Action</th>
    <?php endif; ?>
    <?php endif; ?>  
         
    </tr> 
    <?php $__currentLoopData = $footers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($footer->id); ?></td>
    <td><?php echo e($footer->copyright); ?></td>
    <td><?php echo e($footer->office_detail); ?></td>
   
<td>
        <?php $__currentLoopData = $quickLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($loop->first ? '' : ', '); ?>

        <?php if($type->footer_id == $footer->id): ?>
         <?php echo e($type->quick_links_name); ?> 
         <?php endif; ?>
        
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
     </td>

<td>
        <?php $__currentLoopData = $usefulLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($loop->first ? '' : ', '); ?>

        <?php if($type->footer_id == $footer->id): ?>
         <?php echo e($type->useful_links_name); ?> 
         <?php endif; ?>
        
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
     </td>

     <td>
            <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($loop->first ? '' : ', '); ?>

            <?php if($type->footer_id == $footer->id): ?>
             <?php echo e($type->social_links); ?> 
             <?php endif; ?>
            
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
         </td>

   
    <?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin()): ?>
    <td>
        <a  href="/admin/footers/edit/<?php echo e($footer->id); ?>" class="btn btn-info btn-xs">Edit</a>
    <a onclick="return confirm('are you sure you want to delele?')" href="/admin/footers/<?php echo e($footer->id); ?>" class="btn btn-danger btn-xs">Delete</a>
    </td>
    <?php endif; ?>
    <?php endif; ?>
   
</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </table>
    
 <?php else: ?>
 <p>No Footer Found</p>
 <?php endif; ?>
</div>
</div>
</div>
<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/footers/index.blade.php ENDPATH**/ ?>