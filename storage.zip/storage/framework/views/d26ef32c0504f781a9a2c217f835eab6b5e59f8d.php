<?php echo $__env->make('admin.adminhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.mainnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
    <div class="panel pandel-default">
        <div class="panel-heading">
            <h1 style="text-align:center">Add Footer</h1>
            <br>
            <small style="text-align:center">All filed with <label class="required-field-class">*</label> are
            mandatory.</small>
        </div>
        <div class="panel-body">
            <form action="<?php echo e(route('admin.footers.store')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group <?php echo e($errors->has('copyright')?'has-error':''); ?>">
                    <label for="name">Copyright<label class="required-field-class">*</label></label>
                    <input type="text" class="form-control" name="copyright" id="copyright" value="<?php echo e(old('copyright')); ?>">
                    <?php if($errors->has('copyright')): ?>
                        <span class="help-block">
                            <?php echo e($errors->first('copyright')); ?>

                        </span>
                    <?php endif; ?>
                </div>
            <table class="table table-bordered table-striped" id="tbl_quick_links">
                <thead>
                    <tr>
                        <th>Quick Links Name</th>
                        <th>Quick Link</th>
                        <th style="text-align:center;"><a href="#" class="btn btn-info " id="btnQuickAdd">+</a></th>
                    </tr>
                </thead>
                <tbody class ="quick_links">
                    <tr>
                        <div class="<?php echo e($errors->has('quick_links_name')?'has-error':''); ?>">
                            <td>
                                <input type="text" name="quick_links_name[]" id="js-input-quick_links_name"
                                class="form-control">
                            </td>
                            <?php if($errors->has('quick_links_name')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('quick_links_name')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="<?php echo e($errors->has('quick_links')?'has-error':''); ?>">
                            <td>
                                <input type="text" name="quick_links[]" id="js-input-quick_links"
                                class="form-control">
                            </td>
                            <?php if($errors->has('quick_links')): ?>
                                <span class="help-block">
                                <?php echo e($errors->first('quick_links')); ?>

                                </span> 
                            <?php endif; ?>
                        </div>
                        <td style="text-align:center;"><a href="#" class="btn btn-danger" id="btnQuickSub">-</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-striped" id="tbl_useful_links">
                <thead>
                    <tr>
                    <th>Useful Links Name</th>
                    <th>Useful Link</th>
                    <th style="text-align:center;"><a href="#" class="btn btn-info " id="btnUsefulAdd">+</a>
                    </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <div class="<?php echo e($errors->has('useful_links_name')?'has-error':''); ?>">
                            <td>
                                <input type="text" name="useful_links_name[]" id="js-input-useful_links_name"
                                class="form-control">
                            </td>
                            <?php if($errors->has('useful_links_name')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('useful_links_name')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="<?php echo e($errors->has('useful_links')?'has-error':''); ?>">
                            <td>
                            <input type="text" name="useful_links[]" id="js-input-useful_links"
                            class="form-control"></td>
                            <?php if($errors->has('useful_links')): ?>
                                <span class="help-block">
                                <?php echo e($errors->first('useful_links')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <td style="text-align:center;"><a href="#" class="btn btn-danger" id="btnUsefulSub">-</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-striped" id="tbl_social_links">
                <thead>
                    <tr>
                    <th>Social Link</th>
                    <th>Social Icon</th>
                    <th style="text-align:center;"><a href="#" class="btn btn-info " id="btnSocialAdd">+</a>
                    </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <div class="<?php echo e($errors->has('social_links')?'has-error':''); ?>">
                            <td>
                            <input type="text" name="social_links[]" id="js-input-social_links"
                            class="form-control">
                            </td>
                            <?php if($errors->has('social_links')): ?>
                                <span class="help-block">
                                <?php echo e($errors->first('social_links')); ?>

                                </span> 
                            <?php endif; ?>
                        </div>
                        <div class="<?php echo e($errors->has('social_icon')?'has-error':''); ?>">
                            <td>
                            <input type="text" name="social_icon[]" id="js-input-social_icon"
                            class="form-control"></td>
                            <?php if($errors->has('social_icon')): ?>
                                <span class="help-block">
                                <?php echo e($errors->first('social_icon')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <td style="text-align:center;"><a href="#" class="btn btn-danger" id="btnSocialSub">-</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-striped" id="tbl_contact_links">
                <thead>
                    <tr>
                    <th>Contact Info</th>
                    <th>Icon</th>
                    <th style="text-align:center;"><a href="#" class="btn btn-info " id="btnContactAdd">+</a>
                    </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <div class="<?php echo e($errors->has('contact_info')?'has-error':''); ?>">
                            <td>
                                <input type="text" name="contact_info[]" id="js-input-contact_info"
                                class="form-control">
                            </td>
                            <?php if($errors->has('contact_info')): ?>
                                <span class="help-block">
                                <?php echo e($errors->first('contact_info')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="<?php echo e($errors->has('icon')?'has-error':''); ?>">
                            <td>
                            <input type="text" name="icon[]" id="js-input-icon"
                            class="form-control">
                            </td>
                            <?php if($errors->has('icon')): ?>
                                <span class="help-block">
                                <?php echo e($errors->first('icon')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <td style="text-align:center;"><a href="#" class="btn btn-danger" id="btnContactSub">-</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <button class="btn btn-success">
                Save Footer
                </button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel_Project\rental1\resources\views/admin/footers/create.blade.php ENDPATH**/ ?>