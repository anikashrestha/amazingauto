<!-- Gallary section start--->
<div class="backgroundcolorcustomize">
			<div class="container">
				<section class="ftco-section ftco-category ftco-no-pt ">
					<p class="buttonastext">Brannd</p>
				</section>
			</div>
			<section class="ftco-section ftco-category ftco-no-pt backgroundcolorcustomize">

			<!-- <section class="ftco-section ftco-category ftco-no-pt backgroundcolorcustomize" style="height: 750px;"> -->
			<p style="visibility: hidden;">Gallery</p>
				<div class="container">
					<div class="row" style="margin-top: -120px;">
					<!-- <div class="row" style="margin-top: -70px;"> -->
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product productborder">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-1.jpg"
										alt="Colorlib Template">
									<span class="status">30%</span>
									<div class="overlay"></div>
								
								<div class="text py-3 pb-4 px-3 text-center description">
									<h3> Car 1 </h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span class="mr-2 price-dc">Rs 120000</span><span
													class="price-sale">Rs 80000</span></p>
										</div>
									</div>
                                </div>
                            </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product productborder">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-2.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class="text py-3 pb-4 px-3 text-center description">
									<h3>Car 2</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product productborder">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-3.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class="text py-3 pb-4 px-3 text-center description">
									<h3>Car 3</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product productborder">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-4.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class="text py-3 pb-4 px-3 text-center description">
									<h3>Car 4</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>


						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product productborder">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-5.jpg"
										alt="Colorlib Template">
									<span class="status">30%</span>
									<div class="overlay"></div>
								<div class="text py-3 pb-4 px-3 text-center description">
									<h3>Car 5</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span class="mr-2 price-dc">Rs 1200000</span><span
													class="price-sale">Rs 800000</span></p>
										</div>
									</div>
                                    </a>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product productborder">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-6.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								<div class="text py-3 pb-4 px-3 text-center description">
									<h3>Car 6</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product productborder">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-7.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class="text py-3 pb-4 px-3 text-center description">
									<h3>Car 7</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
						<div class="col-md-6 col-lg-3 ftco-animate">
							<div class="product productborder">
								<a href="#" class="img-prod"><img class="img-fluid" src="images/product-7.jpg"
										alt="Colorlib Template">
									<div class="overlay"></div>
								 
								<div class="text py-3 pb-4 px-3 text-center description">
									<h3>Car 8</h3>
									<div class="d-flex">
										<div class="pricing">
											<p class="price"><span>Rs 1200000</span></p>
										</div>
									</div>
                                </div>
                                </a>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>

	</div>
	<!-- Gallary section end--->
<?php /**PATH F:\laravel_Project\rental1\resources\views/inc/gallery.blade.php ENDPATH**/ ?>