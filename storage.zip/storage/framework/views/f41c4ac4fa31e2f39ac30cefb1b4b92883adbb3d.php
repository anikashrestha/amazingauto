<?php if(session('success')): ?>
<div class="alert alert-success" style="margin:auto;padding:12px;">
<?php echo e(session('success')); ?>

</div>

<?php endif; ?>
<?php /**PATH F:\laravel_Project\rental1\resources\views/inc/messages.blade.php ENDPATH**/ ?>