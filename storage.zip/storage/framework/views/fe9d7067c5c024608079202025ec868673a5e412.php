<?php echo $__env->make('layouts.metaheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
<?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<div class="section-title">
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
                <ol class="breadcrumb">

                <li class="active"><?php echo $page->title; ?></h2>
                </li>
                </ol>
                    <div class="section-content">
                        <?php echo $page->body; ?>                                            </div>
                    </div>
            
         </div>
    </div>
</div>

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.metafooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<style type="text/css">

</style>
<?php /**PATH F:\laravel_Project\rental1\resources\views/dynamic.blade.php ENDPATH**/ ?>